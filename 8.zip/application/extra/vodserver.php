<?php
return array (
  'server6' => 
  array (
    'status' => '1',
    'from' => 'server6',
    'show' => 'VN 6',
    'des' => 'VN6',
    'sort' => '6',
    'tip' => 'VN6',
  ),
  'server5' => 
  array (
    'status' => '1',
    'from' => 'server5',
    'show' => 'VN 5',
    'des' => 'VN5',
    'sort' => '5',
    'tip' => 'VN5',
  ),
  'server4' => 
  array (
    'status' => '1',
    'from' => 'server4',
    'show' => 'VN 4',
    'des' => 'VN4',
    'sort' => '4',
    'tip' => 'VN4',
    'id' => 'server4',
  ),
  'server3' => 
  array (
    'status' => '1',
    'from' => 'server3',
    'show' => 'VN 3',
    'des' => 'VN3',
    'sort' => '3',
    'tip' => 'VN3',
    'id' => 'server3',
  ),
  'server2' => 
  array (
    'status' => '1',
    'from' => 'server2',
    'show' => 'VN 2',
    'des' => 'VN2',
    'sort' => '2',
    'tip' => 'VN2',
    'id' => 'server2',
  ),
  'server1' => 
  array (
    'status' => '1',
    'from' => 'server1',
    'show' => 'VN 1',
    'des' => 'VN1',
    'sort' => '1',
    'tip' => 'VN1',
    'id' => 'server1',
  ),
  'server0' => 
  array (
    'status' => '1',
    'from' => 'server0',
    'show' => 'VN 0',
    'des' => 'VN',
    'sort' => '0',
    'tip' => 'VN',
    'id' => 'server0',
  ),
);