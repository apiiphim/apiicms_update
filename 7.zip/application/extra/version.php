<?php
return array (
    'name' => 'ApiiCMS',
    'copyright' => 'ApiiCMS',
    'url' => '//github.com/apiiphim/apiicms-dev',
    'code' => '7',
    'license' => 'MIT',
);
?>